<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Service for creating websites</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Mono" rel="stylesheet">
   <link rel="stylesheet" href="fonts/icomoon/style.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
   <link rel="stylesheet" href="css/bootstrap-datepicker.css">
   <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
   <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
  <div class="site-wrap">
    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
    <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
       </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    <header class="site-navbar py-3" role="banner">
      <div class="container-fluid">
        <div class="row align-items-center">
     <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
           <li class="active"><a href="#">Main</a></li>
              <li><a href="#speakers">Team</a></li>
              <li><a href="#ceny">Prices</a></li>
              <li><a href="#contacts">Feedback</a></li>
          </ul>
            </nav>
          </div>
     <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
          </div>
        </div>
      </div>
    </header>
    <div class="site-section site-hero">
      <div class="container">
       <div class="row align-items-center">
         <div class="col-md-10">
            <span class="d-block mb-3 caption" data-aos="fade-up" data-aos-delay="100">Build Your Best Website Today</span>
           <h1 class="d-block mb-4" data-aos="fade-up" data-aos-delay="200">The best website development team</h1>
           <a href="#contacts" class="btn-custom" data-aos="fade-up" data-aos-delay="400"><span>Call us</span></a>
          </div>
       </div>
      </div>
   </div>
    <div class="site-section">
     <div class="container">
        <div class="row mb-5">
         <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="site-section-heading">
             <a name="speakers"><h2>Our team</h2></a>
            </div>
          </div>
      <div class="col-lg-5 mt-5 pl-lg-5" data-aos="fade-up" data-aos-delay="200">
            <p></p>
          </div>
        </div>
        <div class="row align-items-center speaker">
          <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <img src="img/22.jpg" alt="Image" class="img-fluid">
          </div>
      <div class="col-lg-6 ml-auto">
            <h2 class="text-white mb-4 name" data-aos="fade-right" data-aos-delay="200">Timoty Austin</h2>
            <div class="bio pl-lg-5">
          <span class="text-uppercase text-primary d-block mb-3" data-aos="fade-right" data-aos-delay="300">Website designer</span>
              <p class="mb-4" data-aos="fade-right" data-aos-delay="400">We make a unique design for your site according to your project or our layout. You will be very happy with the result!</p>
            </div>
      </div>
        </div>
        <div class="row align-items-center speaker">
         <div class="col-lg-6 mb-5 mb-lg-0 order-lg-2" data-aos="fade" data-aos-delay="100">
            <img src="img/33.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-6 ml-auto order-lg-1">
           <h2 class="text-white mb-4 name" data-aos="fade-left" data-aos-delay="200">Jeff Seaman</h2>
            <div class="bio pr-lg-5">
              <span class="text-uppercase text-primary d-block mb-3" data-aos="fade-left" data-aos-delay="300">Code writers</span>
              <p class="mb-4" data-aos="fade-left" data-aos-delay="400">He graduated from professional training in the profession of a website builder. He does his job as professionally as possible. Highest level of skill. </p 
            </div>
         </div>
      </div>        
     </div>
    </div>
    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
        <div class="col-lg-4" data-aos="fade-up">
            <div class="site-section-heading">
           <a name="ceny"><h2>Offers</h2></a>
            </div>
         </div>
          <div class="col-lg-6 mt-5 pl-lg-5" data-aos="fade-up" data-aos-delay="100">
           <p>The table shows prices for popular services. If you have another order, please contact us in a convenient way. </p>
          </div>
        </div>
        <div class="row align-items-stretch program">
         <div class="col-12 border-top border-bottom py-5" data-aos="fade" data-aos-delay="200">
           <div class="row align-items-stretch">
             <div class="col-md-3 text-white mb-3 mb-md-0"><span class="h4">100 USD</span> </div>
              <div class="col-md-9">
               <h2 class="text-white">Simple landing page</h2>
                <span>About 4 pages</span>
             </div>
            </div>
          </div>
          <div class="col-12 border-bottom py-5" data-aos="fade" data-aos-delay="300">
           <div class="row align-items-stretch">
              <div class="col-md-3 text-white mb-3 mb-md-0"><span class="h4">500 USD</span></div>
              <div class="col-md-9">
               <h2 class="text-white">Business card website</h2>
                <span>Up to 10 pages</span>
            </div>
            </div>
          </div>
         <div class="col-12 border-bottom py-5" data-aos="fade" data-aos-delay="400">
            <div class="row align-items-stretch">
            <div class="col-md-3 text-white mb-3 mb-md-0"><span class="h4">1000 USD</span> </div>
              <div class="col-md-9">
                <h2 class="text-white">Corporate website of the company</h2>
               <span>Production time from two months</span>
             </div>
            </div>
          </div>
          </div>
          </div>
        </div>
      </div>
    </div>
    <footer class="site-footer">
      <div class="container">
        <div class="row mb-5">
         <div class="col-md-4">
     <p>Please call +14</p>
    <p>1577 Fulton St,</p>
      <p>email: support@vil.com </p>
          </div>
         <div class="col-md-3 ml-auto">
            <ul class="list-unstyled">
             <li><a href="#">Main</a></li>
              <li><a href="#speakers">Team</a></li>
             <li><a href="#ceny">Prices</a></li>
              <li><a href="#">Privacy Politics</a></li>
              <li><a href="#">Terms</a></li>
            </ul>
         </div>
        </div>
        <div class="row">
           <div class="col-md-12 text-center">
              <div class="border-top pt-5">
             <p>
              </p>
           </div>
         </div>
        </div>
      </div>
    </footer>
  </div>
 <script src="js/jquery-3.3.1.min.js"></script>
 <script src="js/jquery-migrate-3.0.1.min.js"></script>
 <script src="js/jquery-ui.js"></script>
 <script src="js/popper.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script src="js/owl.carousel.min.js"></script>
 <script src="js/jquery.stellar.min.js"></script>
 <script src="js/jquery.countdown.min.js"></script>
 <script src="js/jquery.magnific-popup.min.js"></script>
 <script src="js/bootstrap-datepicker.min.js"></script>
 <script src="js/aos.js"></script>
 <script src="js/main.js"></script>
 </body>
</html>